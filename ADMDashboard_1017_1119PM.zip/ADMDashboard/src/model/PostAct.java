package model;

import java.util.Calendar;

public class PostAct {
	
	public static final String TABLE_NAME = "postact";
	public static final String COL_POSTACTID = "postactID";
	public static final String COL_EVENTID = "status";
	public static final String COL_DATE = "deadline";
	
	private int postactID;
	private Status status;
	private Calendar deadline;
	
	public PostAct() {}

	public PostAct(int postactID, Status status, Calendar deadline) {
		super();
		this.postactID = postactID;
		this.status = status;
		this.deadline = deadline;
	}

	public int getPostactID() {
		return postactID;
	}

	public void setPostactID(int postactID) {
		this.postactID = postactID;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Calendar getDeadline() {
		return deadline;
	}

	public void setDeadline(Calendar deadline) {
		this.deadline = deadline;
	}

}
