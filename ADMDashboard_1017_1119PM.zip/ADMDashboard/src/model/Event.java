package model;

public class Event {
	
	public static final String TABLE_NAME = "event";
	public static final String COL_EVENTID = "eventID";
	public static final String COL_ORGCODE = "orgcode";
	public static final String COL_EVENTNAME = "eventname";
	public static final String COL_EVENTDESC = "eventdesc";
	public static final String COL_FACI = "facilitator";
	
	private int eventID;
	private String orgcode;
	private String eventname;
	private UserType eventdesc;
	private UserType facilitator;
	
	public Event() {}

	public Event(int eventID, String orgcode, String eventname, UserType eventdesc, UserType facilitator) {
		super();
		this.eventID = eventID;
		this.orgcode = orgcode;
		this.eventname = eventname;
		this.eventdesc = eventdesc;
		this.facilitator = facilitator;
	}

	public int getEventID() {
		return eventID;
	}

	public void setEventID(int eventID) {
		this.eventID = eventID;
	}

	public String getOrgcode() {
		return orgcode;
	}

	public void setOrgcode(String orgcode) {
		this.orgcode = orgcode;
	}

	public String getEventname() {
		return eventname;
	}

	public void setEventname(String eventname) {
		this.eventname = eventname;
	}

	public UserType getEventdesc() {
		return eventdesc;
	}

	public void setEventdesc(UserType eventdesc) {
		this.eventdesc = eventdesc;
	}

	public UserType getFacilitator() {
		return facilitator;
	}

	public void setFacilitator(UserType facilitator) {
		this.facilitator = facilitator;
	}

}
