package model;

public class Event_PostAct {
	
	public static final String TABLE_NAME = "event_postact";
	public static final String COL_EVENTID = "eventID";
	public static final String COL_POSTACTID = "postactID";
	
	private int eventID;
	private int postactID;
	
	public Event_PostAct() {}

	public Event_PostAct(int eventID, int postactID) {
		super();
		this.eventID = eventID;
		this.postactID = postactID;
	}

	public int getEventID() {
		return eventID;
	}

	public void setEventID(int eventID) {
		this.eventID = eventID;
	}

	public int getPostactID() {
		return postactID;
	}

	public void setPostactID(int postactID) {
		this.postactID = postactID;
	}

}
